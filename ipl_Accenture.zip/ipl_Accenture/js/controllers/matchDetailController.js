iplApp.controller('matchDetailController', function($scope ,dataStore,$routeParams){
 $scope.currentMatchItem =[];
    $scope.deliveries = [];

$scope.matchdataStore =[];


    dataStore.matches().then(function(data){
    $scope.matchdataStore = data ;
    $scope.matchdataStore.splice(0,1);
    $scope.matchdataStore.pop();
  $scope.currentMatchItem =  $scope.matchdataStore[$routeParams.id-1];
 console.log($scope.currentMatchItem);
});


dataStore.deliveries().then(function(data){
    $scope.deliveries = data ;
    $scope.deliveries.splice(0,1);
    $scope.deliveries.pop();
    

});





});