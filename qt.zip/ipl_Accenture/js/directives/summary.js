iplApp.directive('summary' , function(){

return{


    restrict : "E",
    scope:{ item : "=item"},
    templateUrl :'templates/summary.html',
    link: function(scope,element,attrs){},
    controller : function($scope,$element , $attrs){}

}

});