var iplApp = angular.module('iplApp' , ['ngRoute' , 'ngTouch' , 'ngAnimate' , 'ui.bootstrap','bw.paging']);

iplApp.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "partials/home.html",
         controller : "homeController"
    })
    .when("/matchdetail/:id", {
        templateUrl : "partials/matchdetails.html",
        controller  : "matchDetailController"
    }).otherwise({
         templateUrl : "partials/home.html",
         controller : "homeController"
    });
  
});