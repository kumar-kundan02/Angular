iplApp.controller('homeController', function($scope,dataStore){
$scope.matchdataStore= '';
$scope.matches = [];
$scope.team_1 ='';
$scope.team_2 ='';
$scope.season ='';
$scope.showSearchResult = false;
$scope.currentpage =1;
$scope.currentSearchpage =1;

dataStore.matches().then(function(data){
    $scope.matchdataStore = data ;
    $scope.matchdataStore.splice(0,1);
    $scope.matchdataStore.pop();
    
    for(var i =0 ; i<7 ;i++)
    $scope.matches[i] = $scope.matchdataStore[i];
});

$scope.reframe = function(page){
$scope.currentPage = page;
    var startIndex = (page-1)*7;
    for(var i =0 ; i<7 ;i++){
    $scope.matches[i] = $scope.matchdataStore[startIndex+i];}

}


$scope.searchfunction = function(key,data,parameter){
var resultset = [];
var k=0;
for (var i=0;i<data.length;i++){

if(data[i][key].toLowerCase() == parameter ){
resultset[k] =data[i];
k++;
}


}
return resultset
}
$scope.searchResults =[];
$scope.searchCurrentResults =[];
$scope.resetalert = function(){$scope.showalert=false;}
$scope.search = function(){

var t1 = $scope.team_1.toLowerCase();
var t2 = $scope.team_2.toLowerCase();
var season = $scope.season;
var result =[];
                 if(!t1 && !t2 && !season){$scope.showalert=true;return;}     
                      

if(t1 && t2 && season){ 
    result = $scope.searchfunction( 1,$scope.matchdataStore,season);
    result = $scope.searchfunction( 5,result,t2);
    result = $scope.searchfunction( 4,result,t1);
                
            }
if(t1 && t2 && !season){
  result = $scope.searchfunction( 5,$scope.matchdataStore,t2);
  result = $scope.searchfunction( 4,result,t1);}

if(t1 && !t2 && season){
    result = $scope.searchfunction( 1,$scope.matchdataStore,season);
    result = $scope.searchfunction( 4,result,t1);}
                
        
if(t1 && !t2 && !season){result = $scope.searchfunction( 4,$scope.matchdataStore,t1);}     


if(!t1 && t2 && season){result = $scope.searchfunction( 1,$scope.matchdataStore,season);
    result = $scope.searchfunction( 5,result,t2);}
if(!t1 && t2 && !season){result = $scope.searchfunction( 5,$scope.matchdataStore,t2);}

if(!t1 && !t2 && season){ result = $scope.searchfunction( 1,$scope.matchdataStore,season);}

        $scope.searchResults = result;
  for(var i =0 ; i<7 ;i++)
    $scope.searchCurrentResults[i] = $scope.searchResults[i];
$scope.showSearchResult = true;

}

$scope.reset = function(){$scope.team_1 ='';
$scope.team_2 ='';
$scope.season ='';
$scope.showSearchResult = false;

$scope.currentSearchpage = 1;$scope.currentpage =1;}

$scope.reframesearch = function(page){
$scope.currentSearchpage = page;
        var startIndex = (page-1)*7;
    for(var i =0 ; i<7 ;i++){
    $scope.searchCurrentResults[i] = $scope.searchResults[startIndex+i];

}
}



});
