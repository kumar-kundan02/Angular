iplApp.controller('matchDetailController', function($scope ,dataStore,$routeParams){
$scope.currentMatchItem =[];
$scope.deliveries = [];

$scope.randomIndex  = 0;
$scope.matchdataStore =[];
$scope.currentMatchdata =[];
$scope.team_1_score = 0;
$scope.team_1_wicket = 0;
$scope.team_1_extras =0;
$scope.team_2_score= 0;
$scope.team_2_wicket = 0;
$scope.team_2_extras = 0;


 dataStore.matches().then(function(data){
 $scope.matchdataStore = data ;
 $scope.matchdataStore.splice(0,1);
 $scope.matchdataStore.pop();
 $scope.currentMatchItem =  $scope.matchdataStore[$routeParams.id-1];

 

});


dataStore.deliveries().then(function(data){
    $scope.deliveries = data ;
    $scope.deliveries.splice(0,1);
    $scope.deliveries.pop();

$scope.randomIndex = $scope.binarySearch( $scope.deliveries,parseInt($routeParams.id));

while(parseInt($scope.deliveries[$scope.randomIndex][0]) == parseInt($routeParams.id)){
$scope.randomIndex++;

}
$scope.randomIndex -= 1;


while( parseInt($scope.deliveries[$scope.randomIndex][0]) == parseInt($routeParams.id)  ){

$scope.currentMatchdata.push($scope.deliveries[$scope.randomIndex]);
$scope.randomIndex-- ;
if(!$scope.deliveries[$scope.randomIndex]){break;}
}



for( var m=0; m< $scope.currentMatchdata.length ;m++){
var i = $scope.currentMatchdata[m];
    if(i[9] == 0){
        if(i[1] == 1){
             $scope.team_1_score = $scope.team_1_score + parseInt(i[17]);
             if(i[18] != ''){ $scope.team_1_wicket = $scope.team_1_wicket+1; }
              $scope.team_1_extras = $scope.team_1_extras + parseInt(i[16]);
                    }
        if(i[1] == 2){  
  $scope.team_2_score = $scope.team_2_score + parseInt(i[17]);
             if(i[18] != ''){ $scope.team_2_wicket = $scope.team_2_wicket+1; }
              $scope.team_2_extras = $scope.team_2_extras + parseInt(i[16]);
        }

    }
}

});


$scope.binarySearch = function(arr, x)    {
        var  l = 0, r = arr.length - 1;
        while (l <= r)
        {
            var m = parseInt(l + (r-l)/2);
             if (arr[m][0] == x)
                return m;
           
            if (arr[m][0] < x)
                l = m + 1;
            else
                r = m - 1;
        }
 
        return -1;
    }






});