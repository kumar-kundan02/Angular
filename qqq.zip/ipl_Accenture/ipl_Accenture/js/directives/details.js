iplApp.directive('details' , function(){

return{

    
    restrict : "E",
    scope:{ item : "=item"},
    replace : true,
    templateUrl :'templates/details.html',
    link: function(scope,element,attrs){},
    controller : function($scope,$element , $attrs){}

}

});