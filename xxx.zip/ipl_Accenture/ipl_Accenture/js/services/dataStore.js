iplApp.service('dataStore', function($http,$q) {

    // Service to get Match details

   this.matches =function(){ 
   return $q(function(resolve, reject) 
   {
          $http.get('data/matches.csv').then(function(file){resolve(Papa.parse(file.data).data);});
            });
   }
  // Service to get Delivery details
   this.deliveries =function(){ 
   return $q(function(resolve, reject) 
   {
          $http.get('data/deliveries.csv').then(function(file){resolve(Papa.parse(file.data).data);});
            });
   }

       
 
    
});